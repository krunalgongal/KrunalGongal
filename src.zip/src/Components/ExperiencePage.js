import { Box, Typography } from '@mui/material'
import { blue } from '@mui/material/colors'
import React from 'react'

function ExperiencePage() {
    return (
        <div id='experience'>
        <Box sx={{ backgroundColor: blue['A100'], height: '90vh' }}>
            <Typography>
                ExperiencePages
            </Typography>
        </Box>
        </div>
    )
}

export default ExperiencePage