import { Box } from '@mui/material'
import { blue } from '@mui/material/colors'
import React from 'react'

function AboutPage() {
    return (
        <div id='about'>
        <Box  sx={{ backgroundColor: 'linear-gradient(to bottom, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.9))', height: '100vh' }}>
            <img
                src='https://editorial01.shutterstock.com/preview-440/13945710vt/5316f9ff/Shutterstock_13945710vt.jpg'
                alt='hello'
                style={{

                }}
            />
        </Box>
        </div>
    )
}

export default AboutPage