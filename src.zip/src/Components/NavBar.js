import { AppBar, Box, Button, IconButton, Toolbar, Typography } from '@mui/material'
import { blue, red } from '@mui/material/colors';
import React from 'react'
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ScrollLink } from 'react-scroll';

function NavBar() {
  const navItems = [{ text: 'About', to: 'about' },
  { text: 'Experience', to: 'experience' },
  { text: 'Project', to: 'project' },
  { text: 'Contact', to: 'contact' },];
  const handleDrawerToggle = () => {
    setMobileOpen((prevState) => !prevState);
  };
  const [mobileOpen, setMobileOpen] = useState(false);
  return (
    <AppBar style={{ background: 'transparent', boxShadow: 'none' }} >
      <Toolbar >
        <IconButton
          color="inherit"
          aria-label="open drawer"
          edge="start"
          onClick={handleDrawerToggle}
          sx={{ mr: 2, display: { sm: 'none' } }}
        >

        </IconButton>
        <Typography
          variant="h6"
          component="div"
          sx={{ flexGrow: 1, display: { xs: 'none', sm: 'block', color: red['700'] } }}
        >
          KRUNAL
        </Typography>
        <Box sx={{ display: { xs: 'none', sm: 'block' } }}>
          {/* {navItems.map((item) => (
            // <Link key={item.text} to={item.path} style={{ backgroundColor: blue['A100'], height: '90vh', paddingRight: '20px' }}>
            //   {item.text}
            // </Link>
            <ScrollLink to={item.to} spy={true} smooth={true} duration={500}>{item.text}</ScrollLink>
          ))} */}
          <ScrollLink to="about" spy={true} smooth={true} duration={500}>About</ScrollLink>
          <ScrollLink to="experience" spy={true} smooth={true} duration={500}>Experience</ScrollLink>
          <ScrollLink to="project" spy={true} smooth={true} duration={500}>Project</ScrollLink>
          <ScrollLink to="contact" spy={true} smooth={true} duration={500}>Contact</ScrollLink>
        </Box>
      </Toolbar>
    </AppBar>
  )
}

export default NavBar