import { Box, Typography } from '@mui/material'
import React from 'react'

function ProjectPage() {
  return (
    <Box sx={{maxHeight:'90vh'}}>
        <Typography>
            Hello Project
        </Typography>
    </Box>
  )
}

export default ProjectPage