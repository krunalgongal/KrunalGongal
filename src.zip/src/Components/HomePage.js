import { Box, Divider, Typography } from '@mui/material'
import { blue } from '@mui/material/colors'
import React from 'react'
import { Element } from 'react-scroll'
// import AboutPage from './AboutPage'
// import { blue } from '@mui/material/colors'
// import ExperiencePage from './ExperiencePage'
// import ProjectPage from './ProjectPage'
// import ContactPage from './ContactPage'
// import NavBar from './NavBar'

function HomePage() {
    return (
        <div>

            <Box
                sx={{
                    background: `linear-gradient(to bottom, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.9)), url('./assets/img/heroElement.jpg')`,
                    backgroundSize: "cover",
                    height: "100vh",
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                }}
            >
                <Box textAlign={"center"}>
                    <Typography
                        py={5}
                        variant="h4"
                        component="h4"
                        style={{
                            color: "white", // Text color white
                            fontSize: "40px",
                            fontWeight: "bold",
                        }}
                    >
                        KRUNAL GONGAL
                    </Typography>
                </Box>
            </Box>
            {/* <Divider />
            <AboutPage />
            <Divider />
            <ExperiencePage />
            <Divider />
            <ProjectPage />
            <Divider />
            <ContactPage /> */}


            <Element name="about">
                <Box sx={{ backgroundColor:blue[400], height: '100vh' }}>
                    <img
                        src='https://editorial01.shutterstock.com/preview-440/13945710vt/5316f9ff/Shutterstock_13945710vt.jpg'
                        alt='hello'
                        style={{

                        }}
                    />
                </Box>
            </Element>
            <Element name="experience">
                <h2>Experience Page</h2>
                {/* Experience page content */}
            </Element>
            <Element name="project">
                <h2>Project Page</h2>
                {/* Project page content */}
            </Element>
            <Element name="contact">
                <h2>Contact Page</h2>
                {/* Contact page content */}
            </Element>


        </div>
    )
}

export default HomePage